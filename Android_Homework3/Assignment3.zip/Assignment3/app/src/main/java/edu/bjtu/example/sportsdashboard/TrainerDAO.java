package edu.bjtu.example.sportsdashboard;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TrainerDAO implements ITrainerService {
    private DbOpenHelper helper = null;

    public TrainerDAO(Context context) {
        helper = new DbOpenHelper(context);
    }

    @Override
    public long addTrainer(ContentValues values) {
        boolean flag = false;
        SQLiteDatabase database = null;
        long id = -1;
        try {
            database = helper.getWritableDatabase();
            // 执行insert，返回当前行ID
            id = database.insert("trainer", null, values);
            flag = (id != -1 ? true : false);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (database != null) {
                database.close();
            }
        }
        return id;
    }

    @Override
    public int deleteTrainer(String whereClause, String[] whereArgs) {
        boolean flag = false;
        SQLiteDatabase database = null;
        int count = 0;
        try {
            database = helper.getWritableDatabase();
            // 执行删除操作，返回影响行数
            count = database.delete("trainer", whereClause, whereArgs);
            flag = (count > 0 ? true : false);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (database != null) {
                database.close();
            }
        }
        return count;
    }

    @Override
    public int updateTrainer(ContentValues values, String whereClause,
                             String[] whereArgs) {
        boolean flag = false;
        SQLiteDatabase database = null;
        int count = 0;
        try {
            database = helper.getWritableDatabase();
            // 执行更新操作，返回影响行数
            count = database.update("trainer", values, whereClause, whereArgs);
            flag = (count > 0 ? true : false);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (database != null) {
                database.close();
            }
        }
        return count;
    }

    @Override
    public Cursor viewTrainer(String selection,
                              String[] selectionArgs) {
        SQLiteDatabase database = null;
        Cursor cursor = null;
        Map<String, String> map = new HashMap<String, String>();
        try {
            database = helper.getReadableDatabase();
            // 设置查询条件
            cursor = database.query(true, "trainer", null, null,
                    null, null, null, null, null);
            int cols_len = cursor.getColumnCount();
            while (cursor.moveToNext()) {
                for (int i = 0; i < cols_len; i++) {
                    String cols_key = cursor.getColumnName(i);
                    String cols_value = cursor.getString(cursor
                            .getColumnIndex(cols_key));
                    if (cols_value == null) {
                        cols_value = "";
                    }
                    map.put(cols_key, cols_value);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cursor;
    }

    @Override
    public List<Map<String, String>> listTrainersMaps(String selection,
                                                      String[] selectionArgs) {
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        SQLiteDatabase database = null;
        Cursor cursor = null;
        try {
            database = helper.getReadableDatabase();
            cursor = database.query(false, "trainer", null, selection,
                    selectionArgs, null, null, null, null);
            int cols_len = cursor.getColumnCount();
            while (cursor.moveToNext()) {
                Map<String, String> map = new HashMap<String, String>();
                for (int i = 0; i < cols_len; i++) {
                    String cols_key = cursor.getColumnName(i);
                    String cols_value = cursor.getString(cursor
                            .getColumnIndex(cols_key));
                    if (cols_value == null) {
                        cols_value = "";
                    }
                    map.put(cols_key, cols_value);
                }
                list.add(map);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
