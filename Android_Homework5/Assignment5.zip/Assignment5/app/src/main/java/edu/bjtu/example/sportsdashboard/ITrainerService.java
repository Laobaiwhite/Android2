package edu.bjtu.example.sportsdashboard;

import android.content.ContentValues;
import android.database.Cursor;

import java.util.List;
import java.util.Map;

public interface ITrainerService {

    public long addTrainer(ContentValues values);

    public int deleteTrainer(String whereClause, String[] whereArgs);

    public int updateTrainer(ContentValues values, String whereClause,
                             String[] whereArgs);

    public Cursor viewTrainer(String selection,
                              String[] selectionArgs);

    public List<Map<String, String>> listTrainersMaps(String selection,
                                                      String[] selectionArgs);
}
