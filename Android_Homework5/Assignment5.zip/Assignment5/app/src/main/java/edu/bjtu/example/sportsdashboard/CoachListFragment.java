package edu.bjtu.example.sportsdashboard;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.Nullable;
import android.support.v4.app.ListFragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class CoachListFragment extends ListFragment {

//    String[] players = {"Wang Mo", "Li Jian", "Liu Gang", "David Zhang", "Zhao Wu", "Van Persie", "Oscar"};
//    String[] experience = {
//            "Perfection is not attainable, but if we chase perfection we can catch excellence",
//            "Health & Fitness Lifestyle Transformation.Gym doesn't change live, People do.",
//            "If we chase perfection we can catch excellence",
//            "Gym doesn't change live, People do.",
//            "An accomplished fitness trainer with seven years of experience n hand",
//            "Gym doesn't change live, People do.",
//            "I Love Gym."
//    };
    int[] images = {R.drawable.trainer1, R.drawable.trainer2, R.drawable.trainer3, R.drawable.trainer4, R.drawable.trainer5, R.drawable.trainer6, R.drawable.athelet_1};

    ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();
    SimpleAdapter adapter;
    ListView lv;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // TODO Auto-generated method stub

        //MAP
        HashMap<String, String> map = new HashMap<String, String>();
        List<TrainerInfo> result = querys();
        //FILL
        for (int i = 0; i < 7; i++) {
            map = new HashMap<String, String>();
            map.put("Player", result.get(i).getName());
            map.put("Info",result.get(i).getExperience());
            map.put("Image", Integer.toString(images[i]));

            data.add(map);
        }

        //KEYS IN MAP
        String[] from = {"Player","Info", "Image"};

        //IDS OF VIEWS
        int[] to = {R.id.nameTxt, R.id.infoTxt, R.id.imageView1};

        //ADAPTER
        adapter = new SimpleAdapter(getActivity().getBaseContext(), data, R.layout.trainerlist_item, from, to);
        setListAdapter(adapter);


//        View v = inflater.inflate(R.layout.trainerlist, null);
//        lv=v.findViewById(R.id.trainer_list);
//        lv.setOnItemClickListener(new MyListener());
//        for (int i=0;i<adapter.getCount();i++)
//        {
//            ((View)adapter.getItem(i)).setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    Uri uri=Uri.parse("tel:"+"18800000000");
//                    Intent intent=new Intent(Intent.ACTION_DIAL,uri);
//                    getActivity().startActivity(intent);
//                }
//            });
//        }

        return super.onCreateView(inflater, container, savedInstanceState);
    }

    class MyListener implements OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position,
                                long id) {
            Map<String, Object> mMap = (Map<String, Object>) adapter.getItem(position);
            //Toast.makeText(getActivity(), mMap.get("data").toString(), 0).show();

        }

    }


    public List<TrainerInfo> querys() {
        List<TrainerInfo> result = new ArrayList<TrainerInfo>();
        ContentResolver contentResolver = getContext().getContentResolver();
        Uri uri = Uri
                .parse("content://TrainerProvider/trainer");
        //String where = "address=?";
        String where = "notice_id is";
        String[] where_args = { "NOT NULL" };
        Cursor cursor = contentResolver.query(uri, null, where, where_args,
                null);
        cursor.moveToFirst();
        result.add(new TrainerInfo(cursor.getString(cursor.getColumnIndex("trainer_name")),cursor.getString(cursor.getColumnIndex("trainer_experience"))));
        while (cursor.moveToNext()) {
            result.add(new TrainerInfo(cursor.getString(cursor.getColumnIndex("trainer_name")),cursor.getString(cursor.getColumnIndex("trainer_experience"))));
            //Log.i("main","-------------->" + cursor.getString(cursor.getColumnIndex("name")));
        }
        return  result;
    }


    @Override
    public void onStart() {
        // TODO Auto-generated method stub
        super.onStart();

        getListView().setOnItemClickListener(new OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> av, View v, int pos,
                                    long id) {
                // TODO Auto-generated method stub
                Uri uri=Uri.parse("tel:"+"18801270000");
                Intent intent=new Intent(Intent.ACTION_DIAL,uri);
                getActivity().startActivity(intent);
                //Toast.makeText(getActivity(), data.get(pos).get("Player"), Toast.LENGTH_SHORT).show();

            }
        });
    }

}
