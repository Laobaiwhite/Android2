package edu.bjtu.example.sportsdashboard;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DbOpenHelper extends SQLiteOpenHelper {

    private static String name = "mydb.db";
    private static int version = 1;

    public DbOpenHelper(Context context) {
        super(context, name, null, version);
        }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql1 = "create table trainer(trainer_id integer primary key autoincrement,trainer_name varchar(32),trainer_experience varchar(128))";
        db.execSQL(sql1);

        String ins1="insert into trainer(trainer_name,trainer_experience) values ('Wang Mo','Perfection is not attainable, but if we chase perfection we can catch excellence')";
        String ins2="insert into trainer(trainer_name,trainer_experience) values ('Li Jian','Health & Fitness Lifestyle Transformation.Gym does not change live, People do.')";
        String ins3="insert into trainer(trainer_name,trainer_experience) values ('Liu Gang','If we chase perfection we can catch excellence')";
        String ins4="insert into trainer(trainer_name,trainer_experience) values ('David Zhang','Gym does not change live, People do.')";
        String ins5="insert into trainer(trainer_name,trainer_experience) values ('Zhao Wu','An accomplished fitness trainer with seven years of experience n hand')";
        String ins6="insert into trainer(trainer_name,trainer_experience) values ('Van Persie','Gym does not change live, People do.')";
        String ins7="insert into trainer(trainer_name,trainer_experience) values ('Oscar','I Love Gym.')";

        db.execSQL(ins1);
        db.execSQL(ins2);
        db.execSQL(ins3);
        db.execSQL(ins4);
        db.execSQL(ins5);
        db.execSQL(ins6);
        db.execSQL(ins7);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
