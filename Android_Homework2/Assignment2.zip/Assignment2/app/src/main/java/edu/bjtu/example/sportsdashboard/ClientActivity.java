//package edu.bjtu.example.sportsdashboard;
//public class ClientActivity extends BaseActivity {
//
//
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_http);
//    }
//
//    public void getMethod(View view) {
//        try {
//            ByteArrayOutputStream bos = null;
//            String name = "tom";
//            String password = "123";
//            String url = mUrl + "?name=" + URLEncoder.encode(name, "utf-8")
//                    + "&password=" + URLEncoder.encode(password, "utf-8");
//            HttpClient client = new DefaultHttpClient();
//            HttpGet request = new HttpGet(url);
//            HttpResponse response = client.execute(request);
//            if (response.getStatusLine().getStatusCode() == 200) {
//                InputStream inputStream = response.getEntity().getContent();
//                bos = new ByteArrayOutputStream();
//                int len = 0;
//                byte[] buffer = new byte[1024];
//                while ((len = inputStream.read(buffer)) != -1) {
//                    bos.write(buffer, 0, len);
//                }
//                bos.flush();
//                inputStream.close();
//                bos.close();
//            }
//            String result = new String(bos.toByteArray(), "utf-8");
//        } catch (UnsupportedEncodingException e) {
//            e.printStackTrace();
//        } catch (ClientProtocolException e) {
//            e.printStackTrace();
//        } catch (IllegalStateException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//    public void postMethod(View view) {
//        try {
//            ByteArrayOutputStream bos = null;
//            String name = "tom";
//            String password = "123";
//            HttpClient client = new DefaultHttpClient();
//            HttpPost request = new HttpPost(mUrl);
//            List<NameValuePair> parameters = new ArrayList<NameValuePair>();
//            parameters.add(new BasicNameValuePair("name", URLEncoder.encode(name, "utf-8")));
//            parameters.add(new BasicNameValuePair("password", URLEncoder.encode(password, "utf-8")));
//            HttpEntity entity = new UrlEncodedFormEntity(parameters, "utf-8");
//            request.setEntity(entity);
//            HttpResponse response = client.execute(request);
//            if (response.getStatusLine().getStatusCode() == 200) {
//                InputStream inputStream = response.getEntity().getContent();
//                bos = new ByteArrayOutputStream();
//                int len = 0;
//                byte[] buffer = new byte[1024];
//                while ((len = inputStream.read(buffer)) != -1) {
//                    bos.write(buffer, 0, len);
//                }
//                bos.flush();
//                inputStream.close();
//                bos.close();
//            }
//
//
//
//
//
//
//
//
//
//
//            String result = new String(bos.toByteArray(), "utf-8");
//        } catch (UnsupportedEncodingException e) {
//            e.printStackTrace();
//        } catch (ClientProtocolException e) {
//            e.printStackTrace();
//        } catch (IllegalStateException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//}